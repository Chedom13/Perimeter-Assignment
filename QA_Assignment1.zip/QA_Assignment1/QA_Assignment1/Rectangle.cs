﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QA_Assignment1
{
    public class Rectangle
    {
        private double length;
        private double width;

        public Rectangle(double initLength)
        {

        }

        public Rectangle (double length, double width)
        {
            this.Length = length;
            this.Width = width;
        }

        public Rectangle()
        {
        }

        public double Length { get => length; set {
                if (value >= 0) length = value;
                else throw new InvalidOperationException();
            }
        }

        public double Width
        {
            get => width; set
            {
                if (value >= 0) width = value;
                else throw new InvalidOperationException();
            }
        }

        public double GetLength()
        {
            return length;
        }

        public double GetWidth()
        {
            return width;
        }

        public double SetLength(double length)
        {
            this.length = length;
            return this.length;
        }
        public double SetWidth(double width)
        {
            this.width = width;
            return this.width;
        }

        public double GetPerimeter()
        {
            return (width*2) + (length*2);
        }

        public double GetArea()
        {
            return length*width;
        }

        
    }
}
