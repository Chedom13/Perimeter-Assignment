﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using QA_Assignment1;
using System.Threading.Tasks;
using NUnit.Framework;

namespace QA_Assignment1_Test
{
    [TestFixture()]
    class QA_Assignment1_Test
    {
        [Test()]
        public void GetLength_input4_expectLengthEquals4()
        {
            //Arrange
            double L = 4;
            double W = 5;
            Rectangle testRectangle = new Rectangle(L, W);

            // Act 
            double Length = testRectangle.GetLength();

            // Assert
            Assert.AreEqual(Length, L);
        }

        public void SetLength_input2_expectLengthEquals2()
        {
            //Arrange
            double L = 2;
            double W = 5;
            Rectangle testRectangle = new Rectangle(L, W);

            // Act 
            double Length = testRectangle.GetLength();

            // Assert
            Assert.AreEqual(Length, L);
        }

        public void GetWidth_input5_expectLengthEquals5()
        {
            //Arrange
            double L = 4;
            double W = 5;
            Rectangle testRectangle = new Rectangle(L, W);

            // Act
            double Width = testRectangle.GetWidth();

            // Assert
            Assert.AreEqual(Width, W);
        }

        public void SetWidth_input2_expectLengthEquals2()
        {
            //Arrange
            double L = 4;
            double W = 2;
            Rectangle testRectangle = new Rectangle(L, W);

            // Act 
            double Width = testRectangle.GetWidth();

            // Assert
            Assert.AreEqual(Width, W);
        }

        public void GetPerimeter_input_L4_W5_expectPerimeterEquals18(double initLength, double initWidth)
        {
            //Arrange
            double L = 4;
            double W = 5;
            Rectangle testRectangle = new Rectangle(L, W);

            //Act
            Rectangle r = new Rectangle(initLength, initWidth);
            double expectedPerimeter = (initLength * 2) + (initWidth * 2);

            // Assert
            Assert.AreEqual(expectedPerimeter, r.GetPerimeter());

        }

        public void GetPerimeterNotNull(double initLength, double initWidth)
        {
            Rectangle r = new Rectangle(initLength, initWidth);
            Assert.NotNull(r.GetPerimeter());
        }

        public void GetArea_input_L4_W5_expectAreaEquals20(double initLength, double initWidth)
        {
            //Arrange
            double L = 4;
            double W = 5;
            Rectangle testRectangle = new Rectangle(L, W);

            //Act
            Rectangle r = new Rectangle(L, W);
            double expectedArea = initLength * initWidth;

            // Assert
            Assert.AreEqual(expectedArea, r.GetPerimeter());

        }

        public void GetAreaNotNull(double initLength, double initWidth)
        {
            Rectangle r = new Rectangle(initWidth,initLength);
            Assert.NotNull(r.GetArea());
        }
        

        public void ConstructorWithMinusEntry(double initLength, double initWidth)
        {
            Assert.Throws(
                typeof(InvalidOperationException),
                new TestDelegate(
                    () => new Rectangle(initWidth,initLength)
                ));
        }

    }
}
